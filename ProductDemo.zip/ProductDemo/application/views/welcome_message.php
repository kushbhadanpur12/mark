<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Product Detail</title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url()?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> 
   <!--<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">-->
    <link href="<?php echo base_url()?>assets/css/custom.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url()?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="<?php echo base_url()?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url()?>assets/css/sb-admin.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-countdown/2.0.2/jquery.countdown.css">
     <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css"/>
     <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/css/bootstrapValidator.min.css"/>
  <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url()?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-countdown/2.0.2/jquery.countdown.js"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js"> </script>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
        <a class="navbar-brand" href="index.html">Product Details</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
                    <a class="nav-link" href="<?php echo base_url()?>">
                        <i class="fa fa-fw fa-dashboard"></i>
                        <span class="nav-link-text">Dashboard</span>
                    </a>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Category">
                    <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
                        <i class="fa fa-fw fa-wrench"></i>
                        <span class="nav-link-text">Category</span>
                    </a>
                    <ul class="sidenav-second-level collapse" id="collapseComponents">
                        <?php if(!empty($categorylist)) {
                        foreach($categorylist as $catvalue) {
                        ?>
                            <li>
                                <a href="#" class="categorynameid" data-catname="<?php echo $catvalue->id;?>"><?php echo $catvalue->catname;?></a>
                            </li>
                            <?php } }?>
                    </ul>
                </li>
                <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Prices">
                    <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#pricesdetails" data-parent="#exampleAccordion">
                        <i class="fa fa-fw fa-plus"></i>
                        <span class="nav-link-text">Prices</span>
                    </a>
                    <ul class="sidenav-second-level collapse" id="pricesdetails">
                        <li>
                            <a href="javascript:void(0)" min="0" max="25" class="pricefilter">Under $25</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" min="25" max="50" class="pricefilter">$25 to $50</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" min="50" max="100" class="pricefilter">$50 to $100</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)" min="100" max="200" class="pricefilter">$100 to $200</a>
                        </li>

                    </ul>
                </li>

            </ul>
            <ul class="navbar-nav sidenav-toggler">
                <li class="nav-item">
                    <a class="nav-link text-center" id="sidenavToggler">
                        <i class="fa fa-fw fa-angle-left"></i>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="content-wrapper">
        <div class="container-fluid">
         
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="#">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">My Dashboard</li>
            </ol>
            <!-- Icon Cards-->
            <div class="row">
                <div class="col-xl-3 col-sm-6 mb-3">
                    <div class="card text-white bg-primary o-hidden h-100">
                        <div class="card-body">
                            <div class="card-body-icon">
                                <i class="fa fa-fw fa-comments"></i>
                            </div>
                            <div class="mr-5">26 New Messages!</div>
                        </div>
                        <a class="card-footer text-white clearfix small z-1" href="#">
                            <span class="float-left">View Details</span>
                            <span class="float-right">
                     <i class="fa fa-angle-right"></i>
                     </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-3">
                    <div class="card text-white bg-warning o-hidden h-100">
                        <div class="card-body">
                            <div class="card-body-icon">
                                <i class="fa fa-fw fa-list"></i>
                            </div>
                            <div class="mr-5">11 New Tasks!</div>
                        </div>
                        <a class="card-footer text-white clearfix small z-1" href="#">
                            <span class="float-left">View Details</span>
                            <span class="float-right">
                     <i class="fa fa-angle-right"></i>
                     </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-3">
                    <div class="card text-white bg-success o-hidden h-100">
                        <div class="card-body">
                            <div class="card-body-icon">
                                <i class="fa fa-fw fa-shopping-cart"></i>
                            </div>
                            <div class="mr-5">123 New Orders!</div>
                        </div>
                        <a class="card-footer text-white clearfix small z-1" href="#">
                            <span class="float-left">View Details</span>
                            <span class="float-right">
                     <i class="fa fa-angle-right"></i>
                     </span>
                        </a>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 mb-3">
                    <div class="card text-white bg-danger o-hidden h-100">
                        <div class="card-body">
                            <div class="card-body-icon">
                                <i class="fa fa-fw fa-support"></i>
                            </div>
                            <div class="mr-5">13 New Tickets!</div>
                        </div>
                        <a class="card-footer text-white clearfix small z-1" href="#">
                            <span class="float-left">View Details</span>
                            <span class="float-right">
                     <i class="fa fa-angle-right"></i>
                     </span>
                        </a>
                    </div>
                </div>
            </div>
             <center>
            <div id="clockdiv">
              <div>
                <span class="days"></span>
                <div class="smalltext">Days</div>
              </div>
              <div>
                <span class="hours"></span>
                <div class="smalltext">Hours</div>
              </div>
              <div>
                <span class="minutes"></span>
                <div class="smalltext">Minutes</div>
              </div>
              <div>
                <span class="seconds"></span>
                <div class="smalltext">Seconds</div>
              </div>
            </div>
        </center>
            <div class="row">
                <div class="col-md-10">
                    <div id="mainproduct">
                        <div class="clearfix"></div>
                        <div class="row">
                            <?php if(!empty($productlist)) { 
                     foreach ($productlist as  $value) {          
                   ?>
                                <div class="col-md-3">
                                    <article class="col-item">
                                        <div class="photo">
                                            <div class="options-cart-round">
                                                <button class="btn btn-default" title="Add to cart">
                                                    <span class="fa fa-shopping-cart"></span>
                                                </button>
                                            </div>
                                            <a href="#"> <img src="<?php echo base_url()?>assets/productimage/<?php echo $value->product_image;?>" class="img-responsive" alt="Product Image" /> </a>
                                        </div>
                                        <div class="info">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <span>
                                    <h5><center><?php if(!empty($value->product_name))  echo $value->product_name;  else echo "-";?></center></h5>
                                 </span>
                                                    <span class="price-new">
                                    <center><?php if(!empty($value->Price))  echo '$'.$value->Price;  else echo "-";?></center>
                                 </span>
                                                    <button class="btn btn-success"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add to cart</button>

                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                </div>
                                <?php } } ?>
                        </div>

                    </div>
                    <div id="catwiseproduct"></div>
                    <div class="col-md-12">
                        <div class="pull-right pagination-links">
                            <?php if(!empty($pagination))  echo $pagination;?>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">

                    <div class="form-group">
                        <label for="email">Sort By:</label>
                        &nbsp;
                        <select class="form-control" id="sortingby">
                            <option value="0">Select By</option>
                            <option value="1">Sort by A-Z</option>
                            <option value="2">Sort by Z-A</option>
                            <option value="3">Price: Low to High</option>
                            <option value="4">Price: High to Low</option>
                        </select>
                    </div>
                </div>
            </div>
             
    </div><!-- /.container -->
        </div>

    </div>
    <!-- /Card Columns-->
    </div>
   
   
    <!-- Example DataTables Card-->
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
        <div class="container">
            <div class="text-center">
                <small>Copyright © Your Website 2018</small>
            </div>
        </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    
    <script type="text/javascript">
        var base_url = "<?php echo base_url()?>";
    </script>
    <script src="<?php echo base_url()?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url()?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    </div>
</body>

</html>
<script type="text/javascript">
    $('.categorynameid').on('click', function(e) {
        e.preventDefault();
        var catid = $(this).data('catname');
        var perpage="<?php echo PERPAGE;?>";         
        var pagenumber =$('.pagination li a').data('ci-pagination-page') ? $('.pagination li a').data('ci-pagination-page') : 1;
        var offset = (pagenumber- 1) * perpage;
        //alert(pagenumber);
        $.ajax({
            url: base_url + 'Welcome/showCatData/'+offset,
            type: 'POST',
            data: {
                catid: catid,
                perpage:perpage,

            },
            success: function(data) {
                console.log(data)
                if (data) {
                    var d = $.parseJSON(data);
                    $('#catwiseproduct').html(d.html);
                    $('#mainproduct').hide();
                    $('.pagination-links').html(d.pagination);                   
                    } else {
                    $('#mainproduct').show();
                }
            }
        })
        return false
            //alert(catid);
    });
    $('body').on('click', '.pricefilter', function() {

        var thisAttr = $(this);
        min = thisAttr.attr("min");
        max = thisAttr.attr("max");
        $.ajax({
            url: base_url + 'Welcome/showPrice',
            type: 'POST',
            data: {
                min: min,
                max: max
            },
            success: function(data) {
                if (data) {
                    //alert(data)
                    $('#catwiseproduct').html(data);
                    $('#mainproduct').hide();

                } else {
                    $('#catwiseproduct').html("<span style='color:red'>No Data Found</span>");
                }
            }
        });
    });
    $('body').on('click', '.pagination li a', function(e) {
        e.preventDefault();
        var perpage="<?php echo PERPAGE;?>";
        var offset = ($(this).data('ci-pagination-page') - 1) * perpage;        
        $.ajax({
            url: base_url + 'Welcome/paginate/'+offset,
            type: 'POST',
            data:{'perpage':perpage},
            success: function(data) {
                if (data) {
                    //console.log(data);
                  var d = $.parseJSON(data);
                    $('#catwiseproduct').html(d.html);
                    $('#mainproduct').hide();
                    $('.pagination-links').html(d.pagination);
                } else {
                    $('#mainproduct').show();
                }

            }
        });

    });

    $('#sortingby').on('change', function(event) {
        event.preventDefault();
        var sortval = $('#sortingby').val();
        //alert(sortval);
        $.ajax({
            url: base_url + 'Welcome/sortByData',
            type: 'POST',
            data: {
                sortval: sortval
            },
            success: function(data) {
                if (data) {
                    $('#catwiseproduct').html(data);
                    $('#mainproduct').hide();
                } else {
                    $('#mainproduct').show();
                }
            }
        });

    });
    /*Tooltip*/
    $(function() {
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>

<Script>
    function getTimeRemaining(endtime) {
  var t = Date.parse(endtime) - Date.parse(new Date());
  var seconds = Math.floor((t / 1000) % 60);
  var minutes = Math.floor((t / 1000 / 60) % 60);
  var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
  var days = Math.floor(t / (1000 * 60 * 60 * 24));
  return {
    'total': t,
    'days': days,
    'hours': hours,
    'minutes': minutes,
    'seconds': seconds
  };
}

function initializeClock(id, endtime) {
  var clock = document.getElementById(id);
  var daysSpan = clock.querySelector('.days');
  var hoursSpan = clock.querySelector('.hours');
  var minutesSpan = clock.querySelector('.minutes');
  var secondsSpan = clock.querySelector('.seconds');

  function updateClock() {
    var t = getTimeRemaining(endtime);

    daysSpan.innerHTML = t.days;
    hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
    minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
    secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

    if (t.total <= 0) {
      clearInterval(timeinterval);
    }
  }

  updateClock();
  var timeinterval = setInterval(updateClock, 1000);
}

var deadline = new Date(Date.parse(new Date()) + 15 * 24 * 60 * 60 * 1000);
initializeClock('clockdiv', deadline);
</Script>

<style>
#success_message{ display: none;}
#clockdiv{
    font-family: sans-serif;
    color: #fff;
    display: inline-block;
    font-weight: 100;
    text-align: center;
    font-size: 30px;
}

#clockdiv > div{
    padding: 10px;
    border-radius: 3px;
    background: #00BF96;
    display: inline-block;
}

#clockdiv div > span{
    padding: 15px;
    border-radius: 3px;
    background: #00816A;
    display: inline-block;
}

.smalltext{
    padding-top: 5px;
    font-size: 16px;
}
    .pagination {
        //display: inline-block;
    }
    
    .pagination a {
        color: black;
        float: left;
        padding: 8px 16px;
        text-decoration: none;
        border: 1px solid #ddd;
    }
    
    .pagination a.active {
        background-color: #4CAF50;
        color: white;
        border: 1px solid #4CAF50;
    }
    
    .pagination a:hover:not(.active) {
        background-color: #ddd;
    }
    
    .pagination a:first-child {
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
    }
    
    .pagination a:last-child {
        border-top-right-radius: 5px;
        border-bottom-right-radius: 5px;
    }
    
    .sort_to {
        margin-bottom: 25px;
        padding-right: 20px;
    }
</style>
<script>
     $(document).ready(function() {
    $('#contact_form').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            first_name: {
                validators: {
                        stringLength: {
                        min: 2,
                    },
                        notEmpty: {
                        message: 'Please supply your first name'
                    }
                }
            },
             last_name: {
                validators: {
                     stringLength: {
                        min: 2,
                    },
                    notEmpty: {
                        message: 'Please supply your last name'
                    }
                }
            },
            email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
            phone: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your phone number'
                    },
                    phone: {
                        country: 'US',
                        message: 'Please supply a vaild phone number with area code'
                    }
                }
            },
            address: {
                validators: {
                     stringLength: {
                        min: 8,
                    },
                    notEmpty: {
                        message: 'Please supply your street address'
                    }
                }
            },
            city: {
                validators: {
                     stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please supply your city'
                    }
                }
            },
            state: {
                validators: {
                    notEmpty: {
                        message: 'Please select your state'
                    }
                }
            },
            zip: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your zip code'
                    },
                    zipCode: {
                        country: 'US',
                        message: 'Please supply a vaild zip code'
                    }
                }
            },
            comment: {
                validators: {
                      stringLength: {
                        min: 10,
                        max: 200,
                        message:'Please enter at least 10 characters and no more than 200'
                    },
                    notEmpty: {
                        message: 'Please supply a description of your project'
                    }
                    }
                }
            }
        })
        .on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#contact_form').data('bootstrapValidator').resetForm();

            // Prevent form submission
            e.preventDefault();

            // Get the form instance
            var $form = $(e.target);

            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');

            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });
});


</script>