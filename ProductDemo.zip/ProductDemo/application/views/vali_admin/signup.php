<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/vali-assets/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>SignUp</title>
  </head>
  <style type="text/css">
    .signup-box
    {
      min-height: 500px;
    }
  </style>
  <body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        <h1>SignUp</h1>
      </div>
      <div class="login-box signup-box">  
        <div class="loader" id="loading_spinner"><img src="<?php echo base_url()?>assets/img/Rolling-1s-200px.gif"/></div>  
        <form class="login-form" method="post">  
          <?php if($this->session->flashdata('success_msg')) {
           ?>
           <div class="headermsg alert alert-success alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('success_msg'); ?>
          </div>
           <script type="text/javascript">
              setTimeout(()=>{
                $('.headermsg').slideToggle();
              },3000);
          </script>
          <?php
          }
          ?>
           <?php if($this->session->flashdata('error_msg')) {
           ?>
           <div class="headermsg alert alert-danger alert-dismissible"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('error_msg'); ?>
          </div>
          <script type="text/javascript">
              setTimeout(()=>{
                $('.headermsg').slideToggle();
              },2000);
            </script>
          <?php
          }
          ?>          
           <div class="form-group">
            <label class="control-label">USERNAME</label>
            <input class="form-control" type="text" placeholder="Email" autofocus name="emailid" id="emailid" value="">
          </div>
          <div class="form-group">
            <label class="control-label">PASSWORD</label>
            <input class="form-control" type="password" placeholder="Password" name="password" id="password" value="">
          </div>
          <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                <label>
                  <input type="checkbox"><span class="label-text">Stay Signed in</span>
                </label>
              </div>
              <p class="semibold-text mb-2"><a href="#" data-toggle="flip">Forgot Password ?</a></p>
            </div>
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block"><i class="fa fa-sign-in fa-lg fa-fw"></i>SIGN IN</button>
            <button class="btn btn-danger btn-block"><i class="fa fa-sign-in fa-lg fa-fw"></i>New User Register</button>
          </div>
        </form>
        <form class="forget-form" action="index.html">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Forgot Password ?</h3>
          <div class="form-group">
            <label class="control-label">EMAIL</label>
            <input class="form-control" type="text" placeholder="Email">
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block"><i class="fa fa-unlock fa-lg fa-fw"></i>RESET</button>
          </div>
          <div class="form-group mt-3">
            <p class="semibold-text mb-0"><a href="#" data-toggle="flip"><i class="fa fa-angle-left fa-fw"></i> Back to Login</a></p>
          </div>
        </form>
      </div>
     
    </section>
    <!-- Essential javascripts for application to work-->
    <script src="<?php echo base_url()?>assets/vali-assets/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
      var base_url="<?php echo base_url();?>";
    </script>
    <script src="<?php echo base_url()?>assets/vali-assets/js/popper.min.js"></script>
    <script src="<?php echo base_url()?>assets/vali-assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/vali-assets/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo base_url()?>assets/vali-assets/js/plugins/pace.min.js"></script>
    <script type="text/javascript">
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
    </script>
    <script type="text/javascript">
      $('.login-form').on('submit',function(e){
        e.preventDefault();
        myFunction();
      });
      function myFunction()
      {     
        var email=$("#emailid").val();
        var pass=$("#password").val();
        $(".loader").show();
         setTimeout(function(){
               
                 if(email!="" && pass!="")
           {
            $.ajax
            ({
            type:'post',
            url: base_url+'login/do_login',
            data:{
             email:email,
             password:pass
            },
            success:function(response) {
            var json = $.parseJSON(response);           
            if(json['status']=="success")
            {
              window.location.href="<?php echo base_url()?>dashboard";             
            }
            else
            {              
              window.location.href="<?php echo base_url('Login')?>";              
            }
            }
            });
           }

         else
         {
          window.location.href="<?php echo base_url('Login')?>";             
         }
         $(".loader").hide();

        },2000);
       }

        
</script>
<style type="text/css">
  .loader {
    position: absolute;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: rgb(249,249,249);
    opacity: .8;
    display: none;
}
</style>
  </body>
</html>