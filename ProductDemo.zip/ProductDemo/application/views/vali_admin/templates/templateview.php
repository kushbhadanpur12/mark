<?php $this->load->view('vali_admin/templates/header'); ?>
<?php $this->load->view($template); ?>
<?php $this->load->view('vali_admin/templates/footer'); ?>