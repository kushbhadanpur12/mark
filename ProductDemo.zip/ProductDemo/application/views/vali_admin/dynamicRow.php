 <style type="text/css">
   .mydivcolor
   {
    background-color: #fff;    
   }
   .tableheading
   {
    background-color: #009688;
    color: #fff;
    text-align: center;    
    font-size: 15px;
    
   }
   .talebody
   {
    text-align: center;
    font-size: 14px;
   }
   .btn-text
   {
    color: #fff;
    text-align: center;
    padding: 10px;
    margin: 10px;
   }
   .footer
   {
    background-color: #222d32;
   }
 </style>
 <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> Dynamic Row</h1>
         </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="<?php echo current_url();?>">Dynamic Row Insert</a></li>
        </ul> 
      </div>      
      </div>
      <div class="row mydivcolor">
        <div class="col-md-12">
           <div><a class="btn btn-info btn-sm btn-text pull-right" href="#" id="addrow"><i class="fa fa-plus" aria-hidden="true"></i> Add More</a></div>
             <table class="table table-hover order-list" id="customFields">
              <thead class="tableheading">
                <tr>
                  <th>Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tfoot>
                  <tr class="footer">
                    <td colspan="4"><button type="submit" class="btn btn-info btn-sm pull-right btn-text">Submit</button></td>
                    
                </tr>
              </tfoot>
              <tbody class="talebody">
                <form method="post" action="#">
                <tr>
                  <td><input class="form-control form-control-sm"  type="text"></td>
                  <td><input class="form-control form-control-sm"  type="number"></td>
                  <td><input class="form-control form-control-sm"  type="text"></td>
                  <td>                    
                    <a class="btn btn-danger btn-sm btn-text remCF" href="javascript:void(0);" id="demoSwal"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                  </td>
                </tr>                
                </form>
              </tbody>           
             </table>
           </div>         
      </div>       
    </main>