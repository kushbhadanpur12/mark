<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Login_model extends CI_Model {
	public function insert($table_name='',  $data=''){
		$query=$this->db->insert($table_name, $data);
		//echo $this->db->last_query();die;
		if($query)
			return  $this->db->insert_id();
		else
			return FALSE;
	}

	// Read data using username and password
public function login($data) {
$condition = "useremail =" . "'" . $data['emailid'] . "' AND " . "password =" . "'" . $data['password'] . "'";
$this->db->select('*');
$this->db->from('Login');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();
return $query->result();

}

// Read data from database to show data in admin page
public function read_user_information($useremail) {
$condition = "useremail =" . "'" . $useremail . "'";
$this->db->select('*');
$this->db->from('Login');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();
if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}



}
?>