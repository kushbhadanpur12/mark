<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Common_model extends CI_Model {	

	public function insert($table_name='',  $data=''){
		$query=$this->db->insert($table_name, $data);
		// echo $this->db->last_query();
		// die;
		if($query)
			return $this->db->insert_id();
		else
			return FALSE;		
	}
	

	public function get_result($table_name='', $id_array='',$columns=array(),$order_by=array(),$limit='',$where_in=array()){		
		if(!empty($columns)):
			$all_columns = implode(",", $columns);
			$this->db->select($all_columns);
		endif;
		if(!empty($order_by)):			
			$this->db->order_by($order_by[0], $order_by[1]);
		endif; 
		if(!empty($id_array)):		
			foreach ($id_array as $key => $value){
				$this->db->where($key, $value);
			} 
		endif;	
		if(!empty($where_in)):		
			foreach ($where_in as $key => $value){
				$this->db->where_in($key, $value);
			}
		endif;
		if(!empty($limit) && $limit!=''):	
			$this->db->limit($limit);
		endif;	

		$query=$this->db->get($table_name);
		if($query->num_rows()>0)
			return $query->result();
		else
			return FALSE;
	}
 public function get_row($table_name='', $id_array='',$columns=array(),$order_by=array(),$where_in=array()){
		//echo $table_name;
		//print_r($where_in);die;
		if(!empty($columns)):
			$all_columns = implode(",", $columns);
			$this->db->select($all_columns);
		endif; 
		if(!empty($id_array)):		
			foreach ($id_array as $key => $value){
				$this->db->where($key, $value);
			}
		endif;
		if(!empty($where_in)):		
			foreach ($where_in as $key => $value){
				$this->db->where_in($key, $value);
			} 
		endif;
		if(!empty($order_by)):			
			$this->db->order_by($order_by[0], $order_by[1]);
		endif; 
		$query=$this->db->get($table_name);
			
		if($query->num_rows()>0)
		{
			return $query->row();
		}else
			return FALSE;
	}
	public function get_Products($offset='', $per_page=''){
		$this->db->select('pi.*');
		$this->db->from('product as pi');
		if($offset>=0 && $per_page>0){
      $this->db->limit($per_page,$offset);
			$this->db->order_by('pi.id','desc');
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			if($query->num_rows()>0)
				return $query->result();
			else
				return FALSE;
		}else{
			return $this->db->count_all_results();
		}
	}
	public function get_Products_by_cat($offset='', $per_page='',$catid){
		$this->db->select('pi.*');
		$this->db->from('product as pi');
		$this->db->where('category_id',$catid);
		if($offset>=0 && $per_page>=0){
      $this->db->limit($per_page,$offset);
			$this->db->order_by('pi.id','desc');
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			if($query->num_rows()>0)
				return $query->result();
			else
				return FALSE;
		}else{
			return $this->db->count_all_results();
		}
	}

	public function get_by_price($min='',$max='',$price=''){
		$this->db->select('pi.*');
		$this->db->from('product as pi');	
      //$this->db->limit($per_page,$offset);
			$this->db->order_by('pi.id','desc');
			$this->db->where($price);
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			if($query->num_rows()>0)
				return $query->result();
			else
				return FALSE;
		
	}
	public function get_by_sorting($sortval=''){
		$this->db->select('pi.*');
		$this->db->from('product as pi');	
      //$this->db->limit($per_page,$offset);
		if($sortval==1)
		{
		  
		  $this->db->order_by('pi.product_name','asc');	
		}
		else if($sortval==2)
		{
			$this->db->order_by('pi.product_name','desc');	
		}
		else if($sortval==3)
		{
			$this->db->order_by('pi.Price','asc');
		}
		else if($sortval==4)
		{
			$this->db->order_by('pi.Price','desc');
		}			
			
			$query = $this->db->get();
			//echo $this->db->last_query(); die;
			if($query->num_rows()>0)
				return $query->result();
			else
				return FALSE;
		
	}
public function update($table_name='', $data='', $id_array=''){
		if(!empty($id_array)):
			foreach ($id_array as $key => $value){
				$this->db->where($key, $value);
			}
		endif;
		return $this->db->update($table_name, $data);		
	}

	public function delete($table_name='', $id_array=''){		
	 return $this->db->delete($table_name, $id_array);
	}
}
