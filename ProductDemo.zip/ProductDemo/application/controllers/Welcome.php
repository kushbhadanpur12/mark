<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model');
        $this->perPage = 3;
        
    }
    
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    
    public function index($offset = 0)
    {
        $perpage               = 1;
        $data['offset']        = $offset;
        $data['productlist']   = $this->Common_model->get_Products($offset, $perpage);
        $config                = backend_pagination();
        $config['base_url']    = base_url() . 'Welcome/index';
        $config['total_rows']  = $this->Common_model->get_Products(0, 0);
        $config['per_page']    = $perpage;
        $config['uri_segment'] = 3;
        if (!empty($_SERVER['QUERY_STRING'])) {
            $config['suffix'] = "?" . $_SERVER['QUERY_STRING'];
        }
        if ($config['total_rows'] < $offset) {
            $this->session->set_flashdata('msg_warning', 'Something went wrong ..! Please check it ');
            redirect($_SERVER['HTTP_REFERER']);
        }
        $this->pagination->initialize($config);
        $data['pagination']   = $this->pagination->create_links();
        /*$data['productlist']=$this->Common_model->get_result('product');*/
        $data['categorylist'] = $this->Common_model->get_result('category');
        $this->load->view('welcome_message', $data);
    }
    public function paginate($offset)
    {
        
        $perpage        = $this->input->post('perpage');        
        $productCatData = $this->Common_model->get_Products($offset, $perpage);
        $config                = backend_pagination();
        $config['base_url']    = base_url() . 'Welcome/index/';
        $config['total_rows']  = $this->Common_model->get_Products(0, 0);
        $config['per_page']    = $perpage;
        $config['uri_segment'] = 3;
        if (!empty($_SERVER['QUERY_STRING'])) {
            $config['suffix'] = "?" . $_SERVER['QUERY_STRING'];
        }
        
        $this->pagination->initialize($config);
        
        $data['pagination']   = $this->pagination->create_links();
        $html           = '';
        if (!empty($productCatData)) {
            $html = "<div class='row'>";
            foreach ($productCatData as $value) {
                
                $html .= "<div class='col-md-3'>
            <article class='col-item'>
              <div class='photo'>
              <div class='options-cart-round'>
                <button class='btn btn-default' title='Add to cart'>
                  <span class='fa fa-shopping-cart'></span>
                </button>
              </div>
              <a href='#'> <img src='" . base_url() . "assets/productimage/" . $value->product_image . "' class='img-responsive' alt='Product Image' /> </a>
            </div>
            <div class='info'>
              <div class='row'>
                <div class='col-md-6'>                
                 <h5><center>" . $value->product_name . "</center></h5>
                  <span class='price-new'><center>" . $value->Price . "</center></span>
                  <center> <button class='btn btn-success'><i class='fa fa-cart-plus' aria-hidden='true'></i>
 Add to cart</button></center>                 
                  </div>
              </div>
            </div>
          </article>           
        </div>";
                
                
            }
            $html .= "</div>";
        }
        $data['html'] = $html;

        echo json_encode($data);
    }
    public function showCatData($offset)
    {
         $catid          = $this->input->post('catid');
         $perpage        = $this->input->post('perpage');
         $productCatData = $this->Common_model->get_Products_by_cat($offset,$perpage,$catid);
         $config                = backend_pagination();
        $config['base_url']    = base_url() . 'Welcome/index/';
        $config['total_rows']  = count($productCatData);
        $config['per_page']    = $perpage;
        $config['uri_segment'] = 3;
        if (!empty($_SERVER['QUERY_STRING'])) {
            $config['suffix'] = "?" . $_SERVER['QUERY_STRING'];
        }        
        $this->pagination->initialize($config);        
        $data['pagination']   = $this->pagination->create_links();  
        

      // $productCatData = $this->Common_model->get_Products_by_cat($offset,$perpage,$catid);

        $html           = '';
        
        if (!empty($productCatData)) {

            $html = "<div class='row'>";
            foreach ($productCatData as $value) {
                
                $html .= "<div class='col-md-3'>
            <article class='col-item'>
              <div class='photo'>
              <div class='options-cart-round'>
                <button class='btn btn-default' title='Add to cart'>
                  <span class='fa fa-shopping-cart'></span>
                </button>
              </div>
              <a href='#'> <img src='" . base_url() . "assets/productimage/" . $value->product_image . "' class='img-responsive' alt='Product Image' /> </a>
            </div>
            <div class='info'>
              <div class='row'>
                <div class='col-md-6'>                
                 <h5><center>" . $value->product_name . "</center></h5>
                  <span class='price-new'><center>" . $value->Price . "</center></span>
                  <center> <button class='btn btn-success'><i class='fa fa-cart-plus' aria-hidden='true'></i>
 Add to cart</button></center>                 
                  </div>
              </div>
            </div>
          </article>           
        </div>";
                
                
            }
            $html .= "</div>";
        }
        $data['html'] = $html;
        echo json_encode($data);
        
        //print_r($productCatData);
        
    }
    public function sortByData()
    {
        $sortval        = $this->input->post('sortval');
        $productCatData = $this->Common_model->get_by_sorting($sortval);
        $html           = '';
        if (!empty($productCatData)) {
            $html = "<div class='row'>";
            foreach ($productCatData as $value) {
                $html .= "<div class='col-md-3'>
            <article class='col-item'>
              <div class='photo'>
              <div class='options-cart-round'>
                <button class='btn btn-default' title='Add to cart'>
                  <span class='fa fa-shopping-cart'></span>
                </button>
              </div>
              <a href='#'> <img src='" . base_url() . "assets/productimage/" . $value->product_image . "' class='img-responsive' alt='Product Image' /> </a>
            </div>
            <div class='info'>
              <div class='row'>
                <div class='col-md-6'>             
                 <h5><center>" . $value->product_name . "</center></h5>
                  <span class='price-new'><center>" . $value->Price . "</center></span>
                  <center> <button class='btn btn-success'><i class='fa fa-cart-plus' aria-hidden='true'></i>
 Add to cart</button></center>                 
                  </div>
              </div>
            </div>
          </article>           
        </div>";
                
                
            }
            echo $html .= "</div>";
        }
        
    }
    public function showPrice()
    {
        $min            = $this->input->post('min');
        $max            = $this->input->post('max');
        $price          = 'pi.Price BETWEEN "' . trim($min) . '" and "' . trim($max) . '"';
        $productCatData = $this->Common_model->get_by_price($min, $max, $price);
        $html           = '';
        if (!empty($productCatData)) {
            $html = "<div class='row'>";
            foreach ($productCatData as $value) {
                $html .= "<div class='col-md-3'>
            <article class='col-item'>
              <div class='photo'>
              <div class='options-cart-round'>
                <button class='btn btn-default' title='Add to cart'>
                  <span class='fa fa-shopping-cart'></span>
                </button>
              </div>
              <a href='#'> <img src='" . base_url() . "assets/productimage/" . $value->product_image . "' class='img-responsive' alt='Product Image' /> </a>
            </div>
            <div class='info'>
              <div class='row'>
                <div class='col-md-6'>             
                 <h5><center>" . $value->product_name . "</center></h5>
                  <span class='price-new'><center>" . $value->Price . "</center></span>
                  <center> <button class='btn btn-success'><i class='fa fa-cart-plus' aria-hidden='true'></i>
 Add to cart</button></center>                 
                  </div>
              </div>
            </div>
          </article>           
        </div>";
                
                
            }
            echo $html .= "</div>";
        }
        
        
        //print_r($productCatData);
        
    }
}