<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Login_model');
        
    }
    
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *         http://example.com/index.php/welcome
     *    - or -
     *         http://example.com/index.php/welcome/index
     *    - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    
    public function index()
    {               
      $this->load->view('vali_admin/login');   
    }
     public function do_login()
    {
      $sendData=array();
      // $email=$this->input->post('email');
      // $password= $this->input->post('password');      
      $this->form_validation->set_rules('password', 'Password', 'trim|required');
      $this->form_validation->set_rules('email', 'Email Id', 'trim|required');
      if ($this->form_validation->run() == TRUE){    
           $data = array(
          'emailid' => $this->input->post('email'),
          'password' => $this->input->post('password')
          );
          $result = $this->Login_model->login($data);

          if (!empty($result)) {
           $session_data = array(
          'useremail' => $data['emailid'],
          );

          // Add user data in session
          $this->session->set_userdata('logged_in', $session_data);     
            $sendData=array('status'=>"success",'data'=>$result);
            $this->session->set_flashdata('success_msg', 'Login Successfully.');         
           }
           else
           {
            $sendData=array('status'=>"failed");
            $this->session->set_flashdata('error_msg', 'Invalid Username or Password.');
                              
           }            
         }
        else
           {
            $sendData=array('status'=>"failed");
            $this->session->set_flashdata('error_msg', validation_errors());            
           }
            $myJSONData = json_encode($sendData);
            echo $myJSONData;
            
    }
    public function signUp()
    {               
      $this->load->view('vali_admin/signup');   
    }
        
public function logout() {

//$this->session->sess_destroy();
$this->session->set_flashdata('success_msg', 'Successfully Logout.');
$this->session->unset_userdata('logged_in', $sess_array);
redirect('login');
}
}